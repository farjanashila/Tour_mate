package com.example.mdarifur.tourmate.Constant;

/**
 * Created by MD.Arifur on 8/15/2016.
 */
public class Constant {
    public static final String BASE_URL="http://api.wunderground.com/";
    public static final String API_KEY="b5efba6dc63cc1b1";
    public static final String PLACE_API_KEY="AIzaSyByIk3w7Fn8_dgDaSAmKTA_6IWpuQ6slL4";

    public static String ID = "id";
    public static String NAME = "name";
    public static String IS_LOGIN = "login";
    public static String EMAIL = "email";
    public static String PHONE = "phone";
    public static String IMAGE = "image";
    public static String EMERZENCY = "emerzency";


    public static final String EVENT_ID = "eventid";
    public static final String EVENT_NAME = "event_name";
    public static final String EVENT_TO = "to";
    public static final String START_JOURNEY = "startjourney";
    public static final String END_JOURNEY = "endjourney";
    public static final String EVENT_BUDGET = "budget";
    public static final String CLIENT_EVENT_ID = "id";


    public static final String PHOTO_TEMP = "photo_temp";

}
