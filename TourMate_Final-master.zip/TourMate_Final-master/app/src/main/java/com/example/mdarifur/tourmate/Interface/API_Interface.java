package com.example.mdarifur.tourmate.Interface;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Url;


/**
 * Created by MD.Arifur on 8/12/2016.
 */
public interface API_Interface {


}
